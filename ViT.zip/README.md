# ViT (Vision Transformer from scratch)
re implementation of the paper **AN IMAGE IS WORTH 16 X 16 WORDS :
TRANSFORMERS FOR IMAGE RECOGNITION AT SCALE**.
the current repository is a lighter modification on the released  paper.


## Requirements
thtis repo has been developed under:
>   `python3 : Python 3.8.10`<br>
>   `torch : 1.5.0+cu101`<br>
>   `torchvison: 0.6.0+cu101`

>
for installing the packages and the dependencies use:
>  `pip install -r requirements.txt`